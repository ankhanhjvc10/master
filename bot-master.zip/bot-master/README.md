## VietSpeak

VietSpeak is a non-profit community where people, mostly Vietnamese, learn English through audio recording (indirect communication) and voice chatting (direct communication). Providing a community driven academic but friendly virtual space, VietSpeak leverages free services such as Slack, AirTable, Google Excel, Google Meet, Kadi AI among others. 

## Bots at VietSpeak

There are a couple of bots at VietSpeak such as VietSpeakBot (solely written by @dvbui, Python), @Kiwi and @Voice (both are Nodejs) which are implemented on the shoulder of the giant Slack. This repository created aims to give you the latest version of both @Kiwi and @Voice. PRs are welcome so to say!

## License : MIT
